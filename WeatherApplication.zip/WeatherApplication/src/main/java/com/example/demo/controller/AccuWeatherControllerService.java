package com.example.demo.controller;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class AccuWeatherControllerService {
	private OkHttpClient client;
	private Response response;
	private String cityName;
	private String locationKey;
	private String APIkey = "O3pWXByyepG5BeukHHQAZ4wlZVtV32TC";

	// Getting Data from AccuWeather for Location API

	// Step 1
	// 1:https://dataservice.accuweather.com/locations/v1/search?q=Noida&apikey=O3pWXByyepG5BeukHHQAZ4wlZVtV32TC
	public JSONObject getWeatherLocationDetails() {
		client = new OkHttpClient();
		Request request = new Request.Builder()
				.url("https://dataservice.accuweather.com/locations/v1/search?q=" + getcityName() + "&apikey=" + APIkey)
				.build();

		try {
			response = client.newCall(request).execute();
			return new JSONObject(response.body().string());
		} catch (IOException | JSONException e) {
			e.printStackTrace();
		}
		return null;
	}

	// Getting Data from AccuWeather for Location Key API

	// Step 1
	// 2:https://dataservice.accuweather.com/currentconditions/v1/3146227?apikey=O3pWXByyepG5BeukHHQAZ4wlZVtV32TC
	public JSONObject getWeatherCurrentConditionDetails() {
		client = new OkHttpClient();
		Request request = new Request.Builder().url("https://dataservice.accuweather.com/currentconditions/v1/"
				+ getLocationKey() + "?" + "&apikey=" + APIkey).build();

		try {
			response = client.newCall(request).execute();
			return new JSONObject(response.body().string());
		} catch (IOException | JSONException e) {
			e.printStackTrace();
		}
		return null;
	}

	// Getting required data from Weather JSON API
	public JSONObject returnWeatherTextObject() throws JSONException {
		JSONObject wt = getWeatherCurrentConditionDetails().getJSONObject("WeatherText");
		return wt;
	}

	public JSONObject returnHasPrecipitationObject() throws JSONException {
		JSONObject sys = getWeatherCurrentConditionDetails().getJSONObject("HasPrecipitation");
		return sys;
	}

	public JSONObject returnPrecipitationTypeObject() throws JSONException {
		JSONObject pt = getWeatherCurrentConditionDetails().getJSONObject("PrecipitationType");
		return pt;
	}

	public JSONObject returnIsDayTimeObject() throws JSONException {
		JSONObject visibilityObject = getWeatherCurrentConditionDetails().getJSONObject("IsDayTime");
		return visibilityObject;
	}

	public JSONObject returnTemperatureObject() throws JSONException {
		JSONObject t = getWeatherCurrentConditionDetails().getJSONObject("Temperature");
		return t;
	}

	public String getcityName() {
		return cityName;
	}

	public void setCountryName(String cityName) {
		this.cityName = cityName;
	}

	public String getLocationKey() {
		return locationKey;
	}

	public void setLocationKey(String locationKey) {
		this.locationKey = locationKey;
	}

}
