package com.example.demo.controller;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class WeatherControllerService {

	private OkHttpClient client;
	private Response response;
	private String lat;
	private String lon;
	private String countryCode;
	private int zipCode;

	private String APIkey = "8f59c1bd94266df7653507164b0ab06a";

	// Getting Data from OpenWeather for Geocoder API

	// Step2
	// 1:https://api.openweathermap.org/geo/1.0/zip?zip=201014,IN&appid=8f59c1bd94266df7653507164b0ab06a
	public JSONObject getGeocoderWeatherDetails() {
		client = new OkHttpClient();
		Request request = new Request.Builder().url("https://api.openweathermap.org/geo/1.0/zip?zip=" + getZipCode()
				+ ",IN=" + getCountryCode() + "&appid=" + APIkey).build();

		try {
			response = client.newCall(request).execute();
			return new JSONObject(response.body().string());
		} catch (IOException | JSONException e) {
			e.printStackTrace();
		}
		return null;
	}

	// Getting Data from OpenWeather API for Latitude and Longitude

	// Step2
	// 2:https://api.openweathermap.org/data/2.5/weather?lat=28.53&lon=77.39&appid=8f59c1bd94266df7653507164b0ab06a
	public JSONObject getWeatherDetails() {
		client = new OkHttpClient();
		Request request = new Request.Builder().url("https://api.openweathermap.org/data/2.5/weather?lat=" + getLat()
				+ "&lon=" + getLon() + "&appid=" + APIkey).build();

		try {
			response = client.newCall(request).execute();
			return new JSONObject(response.body().string());
		} catch (IOException | JSONException e) {
			e.printStackTrace();
		}
		return null;
	}

	// Getting required data from Weather JSON API
	// JSON Objects and JSON Arrays

	public JSONArray returnWeatherArray() throws JSONException {
		JSONArray weatherJsonArray = getWeatherDetails().getJSONArray("weather");
		return weatherJsonArray;
	}

	public JSONObject returnMainObject() throws JSONException {
		JSONObject mainObject = getWeatherDetails().getJSONObject("main");
		return mainObject;
	}

	public JSONObject returnVisibilityObject() throws JSONException {
		JSONObject visibilityObject = getWeatherDetails().getJSONObject("visibility");
		return visibilityObject;
	}

	public JSONObject returnWindObject() throws JSONException {
		JSONObject wind = getWeatherDetails().getJSONObject("wind");
		return wind;
	}

	public JSONObject returnSysObject() throws JSONException {
		JSONObject sys = getWeatherDetails().getJSONObject("sys");
		return sys;
	} // to pull the values of Sys from JSON

	public String getLat() {
		return lat;
	}
	
	public void setLat(String lat) {
		this.lat = lat;
	}

	public String getLon() {
		return lon;
	}

	public void setLon(String lon) {
		this.lon = lon;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public int getZipCode() {
		return zipCode;
	}

	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}
}
